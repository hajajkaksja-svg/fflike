// ============ FF BOOST HUB — main.js ============

function toggleMenu(){
  const s = document.getElementById('sidebar');
  const o = document.getElementById('overlay');
  const b = document.getElementById('hamburger');
  const w = document.querySelector('.wrap');
  if(!s) return;
  const isMobile = window.innerWidth <= 900;
  if(isMobile){
    s.classList.toggle('open');
    if(o) o.classList.toggle('show');
    if(b) b.classList.toggle('open');
  } else {
    if(w) w.classList.toggle('side-collapsed');
    if(b) b.classList.toggle('open');
    // Save preference
    try { localStorage.setItem('sidebarCollapsed', w && w.classList.contains('side-collapsed') ? '1' : '0'); } catch(e){}
  }
}

// Restore sidebar state on load (desktop only)
document.addEventListener('DOMContentLoaded', ()=>{
  if(window.innerWidth > 900){
    try {
      if(localStorage.getItem('sidebarCollapsed') === '1'){
        const w = document.querySelector('.wrap');
        const b = document.getElementById('hamburger');
        if(w) w.classList.add('side-collapsed');
        if(b) b.classList.add('open');
      }
    } catch(e){}
  }
});

// Auto close mobile sidebar on outside click
document.addEventListener('click', e=>{
  const s = document.getElementById('sidebar');
  const b = document.getElementById('hamburger');
  if(!s || window.innerWidth > 900) return;
  if(!s.classList.contains('open')) return;
  if(s.contains(e.target) || (b && b.contains(e.target))) return;
  s.classList.remove('open');
  const o = document.getElementById('overlay');
  if(o) o.classList.remove('show');
  if(b) b.classList.remove('open');
});

// Auto close sidebar when clicking a menu link on mobile
document.addEventListener('click', e=>{
  if(window.innerWidth > 900) return;
  const link = e.target.closest('.menu-btn');
  if(!link) return;
  const s = document.getElementById('sidebar');
  const o = document.getElementById('overlay');
  const b = document.getElementById('hamburger');
  if(s) s.classList.remove('open');
  if(o) o.classList.remove('show');
  if(b) b.classList.remove('open');
});

// Reset on resize
window.addEventListener('resize', ()=>{
  const s = document.getElementById('sidebar');
  const o = document.getElementById('overlay');
  const w = document.querySelector('.wrap');
  const b = document.getElementById('hamburger');
  if(window.innerWidth > 900){
    if(s) s.classList.remove('open');
    if(o) o.classList.remove('show');
  } else {
    if(w) w.classList.remove('side-collapsed');
    if(b) b.classList.remove('open');
  }
});

function copyText(t){
  const done = ()=>showToast('Copied to clipboard','success');
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(t).then(done).catch(()=>fallbackCopy(t,done));
  } else fallbackCopy(t,done);
}
function fallbackCopy(t,cb){
  const ta = document.createElement('textarea');
  ta.value=t; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.select();
  try{document.execCommand('copy'); cb&&cb();}catch(e){showToast('Copy failed','error');}
  document.body.removeChild(ta);
}
function showModal(id){
  const el = document.getElementById(id);
  if(el) el.classList.add('show');
}
function hideModal(id){
  const el = document.getElementById(id);
  if(el) el.classList.remove('show');
}
function showProcessing(title, sub){
  const ov = document.getElementById('procOverlay');
  if(!ov) return;
  if(title) ov.querySelector('.proc-title').innerHTML = title;
  if(sub) ov.querySelector('.proc-sub').innerHTML = sub;
  ov.classList.add('show');
}
function hideProcessing(){
  const ov = document.getElementById('procOverlay');
  if(ov) ov.classList.remove('show');
}
function showToast(msg,type){
  const t=document.createElement('div');
  t.textContent=msg;
  const bg = type==='error' ? '#F43F5E' : (type==='info' ? '#8B5CF6' : '#10B981');
  t.style.cssText='position:fixed;bottom:20px;left:50%;transform:translateX(-50%);padding:11px 22px;background:'+bg+';color:#fff;border-radius:12px;font-weight:700;z-index:9999;box-shadow:0 10px 36px rgba(0,0,0,0.5);font-size:12.5px;max-width:90vw;text-align:center;';
  document.body.appendChild(t);
  setTimeout(()=>{t.style.opacity='0';t.style.transition='opacity 0.4s';},1900);
  setTimeout(()=>t.remove(),2400);
}
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){
    document.querySelectorAll('.modal-bg.show').forEach(m=>m.classList.remove('show'));
    const s = document.getElementById('sidebar');
    const o = document.getElementById('overlay');
    const b = document.getElementById('hamburger');
    if(s && s.classList.contains('open')){
      s.classList.remove('open');
      if(o) o.classList.remove('show');
      if(b) b.classList.remove('open');
    }
  }
});